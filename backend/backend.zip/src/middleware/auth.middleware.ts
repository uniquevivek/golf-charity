import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import prisma from '../config/db';

export interface AuthenticatedRequest extends Request {
  user?: {
    id: string;
    email: string;
    role: 'USER' | 'ADMIN';
    fullName?: string | null;
    avatar?: string | null;
    donationPercentage: number;
    selectedCharityId?: string | null;
  };
  token?: string;
}

export async function requireAuth(req: Request, res: Response, next: NextFunction) {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ error: 'Authorization header missing or invalid' });
    }

    const token = authHeader.split(' ')[1];
    const jwtSecret = process.env.SUPABASE_JWT_SECRET;
    
    if (!jwtSecret) {
      console.error('SUPABASE_JWT_SECRET is not configured on the server.');
      return res.status(500).json({ error: 'Server configuration error' });
    }

    // Verify token
    let decoded: any;
    try {
      decoded = jwt.verify(token, jwtSecret);
    } catch (err) {
      return res.status(401).json({ error: 'Invalid or expired auth token' });
    }

    const userId = decoded.sub;
    const email = decoded.email;

    if (!userId || !email) {
      return res.status(401).json({ error: 'Invalid token payload' });
    }

    // Auto-sync user with Postgres DB
    let user = await prisma.user.findUnique({
      where: { id: userId },
    });

    if (!user) {
      // Extract metadata from Supabase token
      const metadata = decoded.user_metadata || {};
      const fullName = metadata.full_name || metadata.fullName || email.split('@')[0];
      const avatar = metadata.avatar_url || metadata.avatar || null;

      user = await prisma.user.create({
        data: {
          id: userId,
          email,
          fullName,
          avatar,
          role: 'USER', // Default role
          donationPercentage: 10, // Default minimum
        },
      });
    }

    // Attach to request
    (req as AuthenticatedRequest).user = user;
    (req as AuthenticatedRequest).token = token;

    next();
  } catch (error) {
    console.error('Authentication middleware error:', error);
    res.status(500).json({ error: 'Internal server authentication error' });
  }
}

export function requireAdmin(req: Request, res: Response, next: NextFunction) {
  const authReq = req as AuthenticatedRequest;
  if (!authReq.user) {
    return res.status(401).json({ error: 'Authentication required' });
  }

  if (authReq.user.role !== 'ADMIN') {
    return res.status(403).json({ error: 'Admin access privileges required' });
  }

  next();
}
